Cartesian library, v.0.9.2 

This library is distributed in source form under LGPL license - similar to FLTK so ypu can scaticaly link it to proprietry code as well. (see license file).

Note: You can find the documentation in cartesian.txt.

The tarbal should contain source code of the libraries (two files: cartesian.cpp and header cartesian.h),
an example program (example.cpp) in the test directory  and documentation in cartesian.txt,
the license and maybe some makefiles in directories like visualc, gnu...

 
-----------------
Makefiles:
I am not able to maintain makefiles but I will add them if you will send me some. 

- Makefile.gnu: you have to change the symbols "FL" and "LIBS" to your needs and actual paths inside this file.

-----------------

Bug-fixes, comments, language correction in documentattion, information about compilation/work success or
their lack are highly appreciated at rkantor@tcd.ie

More info in cartesian.txt


Enjoy,

Roman.