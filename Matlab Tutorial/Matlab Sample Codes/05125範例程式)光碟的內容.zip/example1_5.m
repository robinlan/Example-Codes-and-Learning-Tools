clear
t = (0:0.001:1)';
z = [t t.^2 square(4*t)];
a = [1 zeros(1,5)]';
c = a(:,ones(1,3));
