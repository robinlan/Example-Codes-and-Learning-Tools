clear
[b,a] = butter(5,.4,'s'); % Analog Butterworth filter
