clear
w = bartlett(8);
[w(2:7) triang(6)]
