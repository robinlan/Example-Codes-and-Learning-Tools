clear
x1 = 1:10                              % ��l�T��
[xhat,nd] = cceps(x1)
x2 = icceps(xhat,nd)
