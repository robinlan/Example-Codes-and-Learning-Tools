clear
b = fir1(48,[0.35 0.65]);
freqz(b,1,512)
