clear
x = linspace(-5,5);
y = sinc(x);
plot(x,y,'linewidth',2)
xlabel('Time')
ylabel('Amplitude')
title('Sinc Function')