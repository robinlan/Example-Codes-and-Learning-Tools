clear
bartlett(7)
triang(5)
