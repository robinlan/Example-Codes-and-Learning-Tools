clear
x = [ 4 3 7 -9 1 ]';
y = [ x 2*x x/pi ]
