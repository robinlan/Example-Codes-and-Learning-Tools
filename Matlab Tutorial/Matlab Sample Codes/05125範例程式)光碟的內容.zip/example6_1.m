randn('state',0);
x = randn(5000,1);