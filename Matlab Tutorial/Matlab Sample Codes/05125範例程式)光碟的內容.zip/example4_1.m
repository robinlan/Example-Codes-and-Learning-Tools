clear
n = 50;
w1 = rectwin(n);
w2 = ones(50,1);
