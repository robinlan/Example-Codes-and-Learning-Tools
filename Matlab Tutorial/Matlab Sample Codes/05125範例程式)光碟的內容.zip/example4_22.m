clear
specgramdemo
