clear
y_4 = medfilt1([4 3 5 2 8 9 1],4)
y_3 = medfilt1([4 3 5 2 8 9 1],3)
